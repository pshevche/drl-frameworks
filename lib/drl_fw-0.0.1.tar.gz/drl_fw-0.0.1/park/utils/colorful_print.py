
def print_red(s):
    print('\033[91m' + s + '\033[0m')


def print_orange(s):
    print('\033[93m' + s + '\033[0m')


def print_green(s):
    print('\033[92m' + s + '\033[0m')


def print_blue(s):
    print('\034[92m' + s + '\033[0m')